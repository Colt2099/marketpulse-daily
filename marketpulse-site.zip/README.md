# MarketPulse Daily — static site (prototype)

Static HTML site. No build step. Deploy by importing this folder to Vercel.

Pages:
- index.html   → home (indices, 6 categories of movers, Fear & Greed, macro, analysis, news)
- idx.html     → why an index rose/fell (opened from the index tiles)
- asset.html   → an asset's 5 latest news (opened from a mover)
- article.html → full news read; stocks show clickable metrics, commodities show a candlestick chart (D/W/M)
- metric.html  → explains a metric (P/E, EV/EBITDA, ROI...) + comparison vs index average

Content is sample/placeholder data. The daily pipeline (run separately) will write the real data.
